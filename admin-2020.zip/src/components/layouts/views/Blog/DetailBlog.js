import React, { Component } from 'react'

export default class DetailBlog extends Component {
    render() {
        return (
            <div>DetailBlog</div>
        )
    }
}