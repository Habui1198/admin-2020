import React, { Component } from 'react'

export default class EditBlog extends Component {
    render() {
        return (
            <div>EditBlog</div>
        )
    }
}