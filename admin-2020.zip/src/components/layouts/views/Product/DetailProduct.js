import React, { Component } from 'react'

export default class DetailProduct extends Component {
    render() {
        return (
            <div>hhahaha</div>
        )
    }
}