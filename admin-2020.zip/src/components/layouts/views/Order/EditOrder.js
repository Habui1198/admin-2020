import React, { Component } from 'react'

export default class EditOrder extends Component {
    render() {
        return (
            <div>EditOrder</div>
        )
    }
}