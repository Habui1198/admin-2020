import React, { Component } from 'react'

export default class DetailOrder extends Component {
    render() {
        return (
            <div>DetailOrder</div>
        )
    }
}