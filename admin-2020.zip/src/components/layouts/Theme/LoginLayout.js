import React, { Component } from 'react'
import Login from '../views/Login/Login'

export default class LoginLayout extends Component {
    render() {
        return (
            <Login/>
        )
    }
}